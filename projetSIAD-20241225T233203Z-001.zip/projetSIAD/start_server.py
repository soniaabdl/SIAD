import http.server
import socketserver
import os

PORT = 8000

class Handler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory="public", **kwargs)

def main():
    print(f"Démarrage du serveur sur le port {PORT}...")
    print(f"Ouvrez votre navigateur à l'adresse: http://localhost:{PORT}")
    
    with socketserver.TCPServer(("", PORT), Handler) as httpd:
        print("Serveur démarré. Appuyez sur Ctrl+C pour arrêter.")
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\nArrêt du serveur...")
            httpd.shutdown()

if __name__ == "__main__":
    main() 