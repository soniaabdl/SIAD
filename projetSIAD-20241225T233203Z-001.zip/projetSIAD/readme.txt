# Installez d'abord les dépendances
pip install -r requirements.txt

# Puis démarrez le serveur backend
python server/app.py


# Démarrez le serveur frontend
python start_server.py