import sys
import json
import joblib
import numpy as np
from sklearn.preprocessing import StandardScaler

def load_model():
    try:
        # Charger le modèle et le scaler
        model = joblib.load('server/ml/model.joblib')
        scaler = joblib.load('server/ml/scaler.joblib')
        return model, scaler
    except Exception as e:
        print(f"Erreur lors du chargement du modèle: {str(e)}", file=sys.stderr)
        sys.exit(1)

def predict(features):
    try:
        # Charger le modèle et le scaler
        model, scaler = load_model()
        
        # Convertir les features en array numpy
        features_array = np.array(features).reshape(1, -1)
        
        # Normaliser les features
        features_scaled = scaler.transform(features_array)
        
        # Faire la prédiction
        prediction = model.predict(features_scaled)[0]
        
        # Retourner la prédiction (0 ou 1)
        print(json.dumps(int(prediction)))
        
    except Exception as e:
        print(f"Erreur lors de la prédiction: {str(e)}", file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python predict.py '[features]'", file=sys.stderr)
        sys.exit(1)
    
    try:
        # Récupérer les features depuis les arguments
        features = json.loads(sys.argv[1])
        predict(features)
    except Exception as e:
        print(f"Erreur: {str(e)}", file=sys.stderr)
        sys.exit(1) 