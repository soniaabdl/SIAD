import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.metrics import classification_report, confusion_matrix, ConfusionMatrixDisplay
from sklearn.metrics import precision_score
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
warnings.filterwarnings('ignore')

# Chargement des données
df = pd.read_csv('credit_risk_balanced.csv')

# Préparation des features
# Suppression des colonnes non nécessaires
df = df.drop(['Id'], axis=1)

# Gestion des valeurs manquantes
df['Rate'] = df['Rate'].fillna(df['Rate'].mean())
df['Emp_length'] = df['Emp_length'].fillna(df['Emp_length'].mean())

# Encodage des variables catégorielles
le = LabelEncoder()
df['Home'] = le.fit_transform(df['Home'])
df['Intent'] = le.fit_transform(df['Intent'])
df['Default'] = df['Default'].map({'Y': 1, 'N': 0})

# Séparation features et target
X = df.drop('Default', axis=1)
y = df['Default']

# Division train/test
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Standardisation des features
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Création du modèle Gradient Boosting
gb_model = GradientBoostingClassifier(n_estimators=100, random_state=42)

# Validation croisée
cv_scores = cross_val_score(gb_model, X_train_scaled, y_train, cv=5)
print("\nScores de validation croisée:")
print("Scores individuels:", cv_scores)
print("Score moyen: {:.3f} (+/- {:.3f})".format(cv_scores.mean(), cv_scores.std() * 2))

# Entrainement du modèle final
gb_model.fit(X_train_scaled, y_train)

# Prédictions
y_pred = gb_model.predict(X_test_scaled)

# Matrice de confusion
plt.figure(figsize=(10,8))
cm = confusion_matrix(y_test, y_pred)
ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=['Non Default', 'Default']).plot(cmap='Blues')
plt.title('Matrice de Confusion')
plt.show()

# Évaluation du modèle
print("\nClassification Report:")
print(classification_report(y_test, y_pred))

# Importance des features
feature_importance = pd.DataFrame({
    'feature': X.columns,
    'importance': gb_model.feature_importances_
}).sort_values('importance', ascending=False)

print("\nFeature Importance:")
print(feature_importance)

# Visualisation de l'importance des features
plt.figure(figsize=(10,6))
sns.barplot(x='importance', y='feature', data=feature_importance.head(10))
plt.title('Top 10 Features les plus importantes')
plt.show()

# Calcul de la précision
precision = precision_score(y_test, y_pred)
print("\nPrécision:", round(precision * 100, 2), "%")

# Détail complet des métriques
print("\nRapport de classification détaillé:")
print(classification_report(y_test, y_pred))












import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.metrics import classification_report, confusion_matrix, ConfusionMatrixDisplay
from sklearn.metrics import precision_score
import matplotlib.pyplot as plt
import seaborn as sns
import warnings

# Désactivation des avertissements pour une exécution plus propre
warnings.filterwarnings('ignore')

# Chargement des données
df = pd.read_csv('credit_risk_balanced.csv')

# Vérification des colonnes disponibles dans le dataset
print(df.columns)

# Préparation des features
# Suppression de la colonne 'Id' et 'Default' (target)
X = df.drop(['Id', 'Default'], axis=1)

# Gestion des valeurs manquantes
X['Rate'] = X['Rate'].fillna(X['Rate'].mean())  # Imputer les valeurs manquantes de 'Rate'
X['Emp_length'] = X['Emp_length'].fillna(X['Emp_length'].mean())  # Imputer les valeurs manquantes de 'Emp_length'

# Encodage des variables catégorielles
le = LabelEncoder()
X['Home'] = le.fit_transform(X['Home'])
X['Intent'] = le.fit_transform(X['Intent'])

# Encodage de la target 'Default' en 'Y'/'N' pour éviter la confusion avec les valeurs binaires
y = df['Default'].map({'Y': 1, 'N': 0})  # Vous pouvez également garder 'Y' et 'N' mais il faut être cohérent

# Division train/test (80% pour l'entraînement, 20% pour le test)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Standardisation des features
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Création du modèle Gradient Boosting
gb_model = GradientBoostingClassifier(n_estimators=100, random_state=42)

# Validation croisée pour évaluer la performance du modèle
cv_scores = cross_val_score(gb_model, X_train_scaled, y_train, cv=5)
print("\nScores de validation croisée:")
print("Scores individuels:", cv_scores)
print("Score moyen: {:.3f} (+/- {:.3f})".format(cv_scores.mean(), cv_scores.std() * 2))

# Entraînement du modèle final
gb_model.fit(X_train_scaled, y_train)

# Prédictions sur l'ensemble de test
y_pred = gb_model.predict(X_test_scaled)

# Matrice de confusion pour visualiser les performances du modèle
plt.figure(figsize=(10,8))
cm = confusion_matrix(y_test, y_pred)
ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=['Non Default', 'Default']).plot(cmap='Blues')
plt.title('Matrice de Confusion')
plt.show()

# Évaluation du modèle : rapport de classification
print("\nClassification Report:")
print(classification_report(y_test, y_pred))

# Importance des features : quelles variables sont les plus influentes dans la décision du modèle ?
feature_importance = pd.DataFrame({
    'feature': X.columns,
    'importance': gb_model.feature_importances_
}).sort_values('importance', ascending=False)

print("\nFeature Importance:")
print(feature_importance)

# Visualisation de l'importance des features
plt.figure(figsize=(10,6))
sns.barplot(x='importance', y='feature', data=feature_importance.head(10))
plt.title('Top 10 Features les plus importantes')
plt.show()

# Calcul de la précision du modèle avec labels '1' et '0'
precision = precision_score(y_test, y_pred)
print("\nPrécision:", round(precision * 100, 2), "%")

# Détail complet des métriques (précision, rappel, F1-score, etc.)
print("\nRapport de classification détaillé:")
print(classification_report(y_test, y_pred))
