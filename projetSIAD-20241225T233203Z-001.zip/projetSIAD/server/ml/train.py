import pandas as pd
import joblib
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.ensemble import RandomForestClassifier
from imblearn.over_sampling import SMOTE

# Chargement des données
credit_data = pd.read_csv('credit_risk.csv')

# Suppression des colonnes inutiles
credit_data_cleaned = credit_data.drop(columns=['Id'])

# Séparer les colonnes numériques et catégorielles
numerical_columns = credit_data_cleaned.select_dtypes(include=['float64', 'int64']).columns
categorical_columns = credit_data_cleaned.select_dtypes(include=['object']).columns

# Remplissage des valeurs manquantes
credit_data_cleaned[numerical_columns] = credit_data_cleaned[numerical_columns].fillna(credit_data_cleaned[numerical_columns].mean())
credit_data_cleaned[categorical_columns] = credit_data_cleaned[categorical_columns].apply(lambda x: x.fillna(x.mode()[0]))

# Encodage des variables catégorielles
label_encoder = LabelEncoder()
credit_data_cleaned['Home'] = label_encoder.fit_transform(credit_data_cleaned['Home'])
credit_data_cleaned['Intent'] = label_encoder.fit_transform(credit_data_cleaned['Intent'])
credit_data_cleaned['Default'] = label_encoder.fit_transform(credit_data_cleaned['Default'])

# Séparation des features et de la variable cible
X = credit_data_cleaned.drop(columns=['Default'])
y = credit_data_cleaned['Default']

# Équilibrage des classes avec SMOTE
smote = SMOTE(random_state=42)
X_resampled, y_resampled = smote.fit_resample(X, y)

# Standardisation des données
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X_resampled)

# Entraînement du modèle final
model = RandomForestClassifier(random_state=42)
model.fit(X_scaled, y_resampled)

# Sauvegarde du modèle et du scaler
joblib.dump(model, 'model.joblib')
joblib.dump(scaler, 'scaler.joblib')

print("Modèle et scaler sauvegardés avec succès!") 