from flask import Flask, request, jsonify
from flask_cors import CORS
import pandas as pd
import numpy as np
from openai import OpenAI
import anthropic
import os
import json
from werkzeug.utils import secure_filename
import importlib.util
import sys
from dotenv import load_dotenv

# Chargement des variables d'environnement
load_dotenv()

app = Flask(__name__)
CORS(app)

# Configuration
UPLOAD_FOLDER = 'ml'
ALLOWED_EXTENSIONS = {'py'}
DATASET_PATH = 'credit_risk_balanced.csv'

# Configuration des clés API
client = OpenAI(api_key=os.getenv('OPENAI_API_KEY'))
claude = anthropic.Client(api_key=os.getenv('ANTHROPIC_API_KEY'))

# Vérification des clés API
if not os.getenv('OPENAI_API_KEY') or not os.getenv('ANTHROPIC_API_KEY'):
    print("ATTENTION: Les clés API ne sont pas configurées correctement!")

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def load_custom_model(filename):
    try:
        spec = importlib.util.spec_from_file_location("custom_model", os.path.join(app.config['UPLOAD_FOLDER'], filename))
        module = importlib.util.module_from_spec(spec)
        sys.modules["custom_model"] = module
        spec.loader.exec_module(module)
        return module
    except Exception as e:
        print(f"Erreur lors du chargement du modèle personnalisé: {str(e)}")
        return None

@app.route('/api/upload-model', methods=['POST'])
def upload_model():
    if 'model' not in request.files:
        return jsonify({'error': 'Aucun fichier trouvé'}), 400
    
    file = request.files['model']
    if file.filename == '':
        return jsonify({'error': 'Aucun fichier sélectionné'}), 400
    
    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
        return jsonify({'message': 'Modèle chargé avec succès'}), 200
    
    return jsonify({'error': 'Type de fichier non autorisé'}), 400

@app.route('/api/train-model', methods=['POST'])
def train_model():
    try:
        data = request.json
        model_type = data.get('modelType')
        
        # Vérification des clés API
        if model_type == 'gpt4' and not os.getenv('OPENAI_API_KEY'):
            return jsonify({'error': 'Clé API OpenAI non configurée'}), 400
        elif model_type == 'claude' and not os.getenv('ANTHROPIC_API_KEY'):
            return jsonify({'error': 'Clé API Anthropic non configurée'}), 400
        
        dataset = pd.read_csv(DATASET_PATH)
        
        if model_type == 'gpt4':
            # Entraînement avec GPT-4
            response = client.chat.completions.create(
                model="gpt-4",
                messages=[
                    {"role": "system", "content": "Vous êtes un expert en analyse de risque de crédit."},
                    {"role": "user", "content": f"Voici les données d'entraînement: {dataset.head().to_json()}"}
                ]
            )
            return jsonify({'message': 'Modèle GPT-4 prêt'}), 200
            
        elif model_type == 'claude':
            # Entraînement avec Claude
            response = claude.messages.create(
                model="claude-2",
                max_tokens=1000,
                messages=[{
                    "role": "user",
                    "content": f"Analysez ces données de crédit: {dataset.head().to_json()}"
                }]
            )
            return jsonify({'message': 'Modèle Claude prêt'}), 200
            
        elif model_type == 'custom':
            # Chargement et entraînement du modèle personnalisé
            custom_model = load_custom_model('custom_model.py')
            if custom_model and hasattr(custom_model, 'train'):
                custom_model.train(dataset)
                return jsonify({'message': 'Modèle personnalisé entraîné avec succès'}), 200
            else:
                return jsonify({'error': 'Modèle personnalisé invalide'}), 400
        
        return jsonify({'error': 'Type de modèle non supporté'}), 400
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/predict', methods=['POST'])
def predict():
    try:
        data = request.json
        model_type = data.get('modelType')
        input_data = data.get('data')
        
        # Vérification des clés API
        if model_type == 'gpt4' and not os.getenv('OPENAI_API_KEY'):
            return jsonify({'error': 'Clé API OpenAI non configurée'}), 400
        elif model_type == 'claude' and not os.getenv('ANTHROPIC_API_KEY'):
            return jsonify({'error': 'Clé API Anthropic non configurée'}), 400
        
        if model_type == 'gpt4':
            # Prédiction avec GPT-4
            response = client.chat.completions.create(
                model="gpt-4",
                messages=[
                    {"role": "system", "content": "Vous êtes un expert en analyse de risque de crédit."},
                    {"role": "user", "content": f"Analysez ce profil de crédit et donnez une probabilité d'approbation entre 0 et 1: {json.dumps(input_data)}"}
                ]
            )
            # Analyse de la réponse pour extraire une probabilité
            try:
                # Tentative d'extraction d'un nombre de la réponse
                response_text = response.choices[0].message.content
                import re
                probability_match = re.search(r'(\d*\.?\d+)', response_text)
                if probability_match:
                    probability = float(probability_match.group(1))
                    # Normaliser entre 0 et 1 si nécessaire
                    if probability > 1:
                        probability = probability / 100
                else:
                    probability = 0.5  # Valeur par défaut
            except:
                probability = 0.5  # Valeur par défaut en cas d'erreur
            
        elif model_type == 'claude':
            # Prédiction avec Claude
            response = claude.messages.create(
                model="claude-2",
                max_tokens=1000,
                messages=[{
                    "role": "user",
                    "content": f"Évaluez ce profil de crédit et donnez une probabilité d'approbation entre 0 et 1: {json.dumps(input_data)}"
                }]
            )
            # Analyse de la réponse pour extraire une probabilité
            try:
                # Tentative d'extraction d'un nombre de la réponse
                response_text = response.content[0].text
                import re
                probability_match = re.search(r'(\d*\.?\d+)', response_text)
                if probability_match:
                    probability = float(probability_match.group(1))
                    # Normaliser entre 0 et 1 si nécessaire
                    if probability > 1:
                        probability = probability / 100
                else:
                    probability = 0.5  # Valeur par défaut
            except:
                probability = 0.5  # Valeur par défaut en cas d'erreur
            
        elif model_type == 'custom':
            # Prédiction avec le modèle personnalisé
            custom_model = load_custom_model('custom_model.py')
            if custom_model and hasattr(custom_model, 'predict'):
                probability = custom_model.predict(input_data)
            else:
                return jsonify({'error': 'Modèle personnalisé invalide'}), 400
        
        return jsonify({
            'probability': float(probability),
            'recommendation': 'approved' if probability > 0.5 else 'rejected'
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    os.makedirs(UPLOAD_FOLDER, exist_ok=True)
    app.run(debug=True, port=5000) 