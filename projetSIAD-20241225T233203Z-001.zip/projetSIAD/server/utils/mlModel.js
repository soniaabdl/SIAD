import { spawn } from 'child_process';
import path from 'path';

class MLModel {
    async predict(data) {
        try {
            // Formatage des données pour le modèle
            const features = [
                data.age || 0,
                data.income || 0,
                data.homeStatus === 'OWN' ? 1 : 0,
                data.employmentLength || 0,
                data.employmentStatus ? 1 : 0,
                data.loanAmount || 0,
                12, // Taux d'intérêt fixe
                data.loanPurpose === 'PERSONAL' ? 1 : 0,
                30, // Ratio dette/revenu fixe
                5   // Historique de crédit fixe
            ];

            // Exécuter le script Python
            const pythonProcess = spawn('python', [
                path.join(process.cwd(), 'server/ml/predict.py'),
                JSON.stringify(features)
            ]);

            return new Promise((resolve, reject) => {
                let result = '';
                let error = '';

                pythonProcess.stdout.on('data', (data) => {
                    result += data.toString();
                });

                pythonProcess.stderr.on('data', (data) => {
                    error += data.toString();
                });

                pythonProcess.on('close', (code) => {
                    if (code !== 0) {
                        console.error('Erreur ML:', error);
                        resolve('default'); // Par défaut, considérer comme risqué
                    } else {
                        const prediction = JSON.parse(result.trim());
                        resolve(prediction === 1 ? 'default' : 'non-default');
                    }
                });
            });
        } catch (error) {
            console.error('Erreur prédiction:', error);
            return 'default'; // Par défaut, considérer comme risqué
        }
    }
}

export default new MLModel();