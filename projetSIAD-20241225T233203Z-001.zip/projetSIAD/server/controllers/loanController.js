import LoanApplication from '../models/LoanApplication.js';
import mlModel from '../utils/mlModel.js';

const createLoanApplication = async (req, res) => {
    try {
        const {
            age,
            income,
            homeStatus,
            employmentLength,
            loanPurpose,
            loanAmount,
            employmentStatus
        } = req.body;

        const interestRate = 0.12; // 12% taux d'intérêt annuel fixe
        const percentIncome = (loanAmount / income) * 100;
        const creditHistory = 1; // Par défaut, on suppose un bon historique

        const prediction = await mlModel.predict({
            income: Number(income),
            loanAmount: Number(loanAmount),
            employmentStatus,
            employmentLength: Number(employmentLength)
        });

        const loanApplication = await LoanApplication.create({
            user: req.user._id,
            age: Number(age),
            income: Number(income),
            homeStatus,
            employmentLength: Number(employmentLength),
            loanPurpose,
            loanAmount: Number(loanAmount),
            interestRate,
            employmentStatus: employmentStatus === '1',
            percentIncome,
            creditHistory,
            status: 'pending',
            mlPrediction: prediction
        });

        res.status(201).json({
            success: true,
            data: loanApplication
        });
    } catch (error) {
        console.error('Erreur création demande:', error);
        res.status(400).json({ 
            success: false,
            message: 'Erreur lors de la création de la demande de prêt',
            error: error.message 
        });
    }
};

const getLoanApplications = async (req, res) => {
    try {
        const query = req.user.role === 'banker' ? {} : { user: req.user._id };
        const loanApplications = await LoanApplication.find(query)
            .populate('user', 'name email')
            .sort('-createdAt');
        res.json({
            success: true,
            data: loanApplications
        });
    } catch (error) {
        res.status(400).json({ 
            success: false,
            message: 'Erreur lors de la récupération des demandes',
            error: error.message 
        });
    }
};

const updateLoanStatus = async (req, res) => {
    try {
        const { status } = req.body;
        const loanApplication = await LoanApplication.findById(req.params.id);

        if (!loanApplication) {
            return res.status(404).json({ 
                success: false,
                message: 'Demande de prêt non trouvée' 
            });
        }

        loanApplication.status = status;
        const updatedLoan = await loanApplication.save();
        
        res.json({
            success: true,
            data: updatedLoan
        });
    } catch (error) {
        res.status(400).json({ 
            success: false,
            message: 'Erreur lors de la mise à jour du statut',
            error: error.message 
        });
    }
};

const getLoanStats = async (req, res) => {
    try {
        const stats = await LoanApplication.aggregate([
            {
                $group: {
                    _id: '$status',
                    count: { $sum: 1 }
                }
            }
        ]);

        const dailyStats = await LoanApplication.aggregate([
            {
                $group: {
                    _id: { $dateToString: { format: '%Y-%m-%d', date: '$createdAt' } },
                    count: { $sum: 1 }
                }
            },
            { $sort: { '_id': 1 } },
            { $limit: 30 }
        ]);

        res.json({
            success: true,
            data: { stats, dailyStats }
        });
    } catch (error) {
        res.status(400).json({ 
            success: false,
            message: 'Erreur lors de la r��cupération des statistiques',
            error: error.message 
        });
    }
};

const simulateLoan = async (req, res) => {
    try {
        const { loanAmount, duration, income } = req.body;

        // Validation des données
        if (!loanAmount || !duration || !income) {
            return res.status(400).json({
                success: false,
                message: 'Tous les champs sont requis'
            });
        }

        if (loanAmount <= 0 || duration <= 0 || income <= 0) {
            return res.status(400).json({
                success: false,
                message: 'Les valeurs doivent être positives'
            });
        }

        const interestRate = 0.12; // 12% taux d'intérêt annuel
        const monthlyInterestRate = interestRate / 12;

        // Calcul du paiement mensuel
        const monthlyPayment = (loanAmount * monthlyInterestRate * Math.pow(1 + monthlyInterestRate, duration)) /
            (Math.pow(1 + monthlyInterestRate, duration) - 1);

        // Calcul des totaux
        const totalPayment = monthlyPayment * duration;
        const totalInterest = totalPayment - loanAmount;

        // Vérification de la capacité de remboursement
        const monthlyIncome = income / 12;
        const debtToIncomeRatio = monthlyPayment / monthlyIncome;

        if (debtToIncomeRatio > 0.4) {
            return res.status(400).json({
                success: false,
                message: 'Le montant des mensualités dépasse 40% de vos revenus mensuels'
            });
        }

        res.json({
            success: true,
            data: {
                monthlyPayment: Math.round(monthlyPayment),
                totalPayment: Math.round(totalPayment),
                totalInterest: Math.round(totalInterest),
                duration,
                interestRate: interestRate * 100,
                debtToIncomeRatio: Math.round(debtToIncomeRatio * 100)
            }
        });
    } catch (error) {
        console.error('Erreur simulation prêt:', error);
        res.status(400).json({
            success: false,
            message: 'Erreur lors de la simulation',
            error: error.message
        });
    }
};

export {
    createLoanApplication,
    getLoanApplications,
    updateLoanStatus,
    getLoanStats,
    simulateLoan
};