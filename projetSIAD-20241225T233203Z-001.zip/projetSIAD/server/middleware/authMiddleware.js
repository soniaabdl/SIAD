import jwt from 'jsonwebtoken';
import User from '../models/User.js';

const protect = async (req, res, next) => {
    try {
        let token;
        
        // Check JWT in cookie first
        const cookieToken = req.cookies.jwt;
        
        // Then check Authorization header
        const authHeader = req.headers.authorization;
        if (authHeader && authHeader.startsWith('Bearer ')) {
            token = authHeader.split(' ')[1];
        }
        
        // Use cookie token if no bearer token
        token = token || cookieToken;

        if (!token) {
            return res.status(401).json({ 
                success: false,
                message: 'Non autorisé - Token manquant' 
            });
        }

        try {
            const decoded = jwt.verify(token, process.env.JWT_SECRET);
            const user = await User.findById(decoded.userId).select('-password');

            if (!user) {
                return res.status(401).json({ 
                    success: false,
                    message: 'Non autorisé - Utilisateur non trouvé' 
                });
            }

            req.user = user;
            next();
        } catch (error) {
            if (error.name === 'JsonWebTokenError') {
                return res.status(401).json({ 
                    success: false,
                    message: 'Non autorisé - Token invalide' 
                });
            } else if (error.name === 'TokenExpiredError') {
                return res.status(401).json({ 
                    success: false,
                    message: 'Non autorisé - Token expiré' 
                });
            }
            throw error;
        }
    } catch (error) {
        res.status(401).json({ 
            success: false,
            message: 'Non autorisé - Erreur d\'authentification' 
        });
    }
};

const banker = (req, res, next) => {
    if (req.user && req.user.role === 'banker') {
        next();
    } else {
        res.status(403).json({ 
            success: false,
            message: 'Non autorisé - Accès réservé aux banquiers' 
        });
    }
};

export { protect, banker };