import mongoose from 'mongoose';

const loanApplicationSchema = new mongoose.Schema({
    user: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    age: {
        type: Number,
        required: true
    },
    income: {
        type: Number,
        required: true
    },
    homeStatus: {
        type: String,
        enum: ['RENT', 'OWN', 'MORTGAGE'],
        required: true
    },
    employmentLength: {
        type: Number,
        required: true
    },
    loanPurpose: {
        type: String,
        enum: ['PERSONAL', 'EDUCATION', 'MEDICAL', 'BUSINESS'],
        required: true
    },
    loanAmount: {
        type: Number,
        required: true
    },
    interestRate: {
        type: Number,
        required: true
    },
    employmentStatus: {
        type: Boolean,
        required: true
    },
    percentIncome: {
        type: Number,
        required: true
    },
    creditHistory: {
        type: Number,
        required: true
    },
    status: {
        type: String,
        enum: ['pending', 'approved', 'rejected'],
        default: 'pending'
    },
    mlPrediction: {
        type: String,
        enum: ['default', 'non-default'],
        required: false
    },
    documents: [{
        type: String
    }]
}, {
    timestamps: true
});

const LoanApplication = mongoose.model('LoanApplication', loanApplicationSchema);
export default LoanApplication;