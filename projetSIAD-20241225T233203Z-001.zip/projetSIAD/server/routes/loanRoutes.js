import express from 'express';
import { protect, banker } from '../middleware/authMiddleware.js';
import {
    createLoanApplication,
    getLoanApplications,
    updateLoanStatus,
    getLoanStats,
    simulateLoan
} from '../controllers/loanController.js';

const router = express.Router();

router.route('/')
    .post(protect, createLoanApplication)
    .get(protect, getLoanApplications);

router.put('/:id/status', protect, banker, updateLoanStatus);
router.get('/stats', protect, banker, getLoanStats);
router.post('/simulate', protect, simulateLoan);

export default router;