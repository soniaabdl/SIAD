import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier
import joblib

class CreditRiskModel:
    def __init__(self):
        self.model = RandomForestClassifier(n_estimators=100, random_state=42)
        self.scaler = StandardScaler()
        self.is_trained = False
        
    def preprocess_data(self, data):
        """Prétraitement des données"""
        if isinstance(data, pd.DataFrame):
            # Pour les données d'entraînement
            features = data[['age', 'income', 'employment_length', 'loan_amount']]
            return self.scaler.fit_transform(features) if not self.is_trained else self.scaler.transform(features)
        else:
            # Pour une seule prédiction
            features = np.array([[
                float(data['age']),
                float(data['income']),
                float(data['employment_length']),
                float(data['loan_amount'])
            ]])
            return self.scaler.transform(features)
    
    def train(self, dataset):
        """Entraînement du modèle"""
        X = self.preprocess_data(dataset)
        y = dataset['target']  # Supposons que la colonne cible s'appelle 'target'
        
        # Division des données
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
        
        # Entraînement
        self.model.fit(X_train, y_train)
        self.is_trained = True
        
        # Sauvegarde du modèle
        joblib.dump(self.model, 'ml/credit_risk_model.joblib')
        joblib.dump(self.scaler, 'ml/scaler.joblib')
        
        # Évaluation
        train_score = self.model.score(X_train, y_train)
        test_score = self.model.score(X_test, y_test)
        
        print(f"Score d'entraînement: {train_score:.3f}")
        print(f"Score de test: {test_score:.3f}")
        
    def predict(self, input_data):
        """Prédiction pour de nouvelles données"""
        if not self.is_trained:
            try:
                self.model = joblib.load('ml/credit_risk_model.joblib')
                self.scaler = joblib.load('ml/scaler.joblib')
                self.is_trained = True
            except:
                raise Exception("Le modèle n'est pas entraîné et aucun modèle sauvegardé n'a été trouvé")
        
        X = self.preprocess_data(input_data)
        probabilities = self.model.predict_proba(X)
        return float(probabilities[0][1])  # Retourne la probabilité de la classe positive

# Instance globale du modèle
model = CreditRiskModel()

# Fonctions d'interface pour le serveur Flask
def train(dataset):
    """Interface d'entraînement pour le serveur Flask"""
    return model.train(dataset)

def predict(input_data):
    """Interface de prédiction pour le serveur Flask"""
    return model.predict(input_data) 