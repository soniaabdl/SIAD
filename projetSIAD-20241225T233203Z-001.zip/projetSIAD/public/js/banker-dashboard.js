// Check authentication
const userInfo = JSON.parse(localStorage.getItem('userInfo') || '{}');
if (!userInfo || !userInfo.token || userInfo.role !== 'banker') {
    window.location.href = '/login.html';
}

// API Headers
const getHeaders = () => ({
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${userInfo.token}`
});

// Initialize user profile
function initializeUserProfile() {
    try {
        document.getElementById('userName').textContent = userInfo.name || 'Banquier';
        const profileImage = document.getElementById('profileImage');
        if (profileImage) {
            profileImage.src = userInfo.profileImage || '/uploads/default-profile.png';
            profileImage.onerror = () => {
                profileImage.src = '/uploads/default-profile.png';
            };
        }
    } catch (error) {
        console.error('Erreur lors de l\'initialisation du profil:', error);
    }
}

// Theme handling
const body = document.body;
const themeToggle = document.getElementById('themeToggle');
const savedTheme = localStorage.getItem('theme');

if (savedTheme) {
    body.classList.add(savedTheme);
    updateThemeIcon();
}

themeToggle.addEventListener('click', () => {
    body.classList.toggle('dark-mode');
    updateThemeIcon();
    localStorage.setItem('theme', body.classList.contains('dark-mode') ? 'dark-mode' : '');
});

function updateThemeIcon() {
    const icon = themeToggle.querySelector('i');
    if (body.classList.contains('dark-mode')) {
        icon.classList.remove('fa-moon');
        icon.classList.add('fa-sun');
    } else {
        icon.classList.remove('fa-sun');
        icon.classList.add('fa-moon');
    }
}

// Load user profile
document.getElementById('userName').textContent = userInfo.name;
if (userInfo.profileImage) {
    document.getElementById('profileImage').src = userInfo.profileImage;
}

// Load statistics
async function loadStats() {
    try {
        const response = await fetch('/api/loans/stats', {
            headers: getHeaders(),
            credentials: 'include'
        });

        if (!response.ok) {
            if (response.status === 401) {
                localStorage.removeItem('userInfo');
                window.location.href = '/login.html';
                return;
            }
            const errorData = await response.json();
            throw new Error(errorData.message || 'Erreur lors du chargement des statistiques');
        }

        const result = await response.json();
        
        if (result.success) {
            updateStatistics(result.data.stats);
            updateChart(result.data.stats);
        } else {
            throw new Error(result.message || 'Erreur lors du chargement des statistiques');
        }
    } catch (error) {
        showError(error.message || 'Erreur lors du chargement des statistiques');
    }
}

function updateStatistics(stats) {
    let total = 0;
    const statMap = {
        'pending': 'pendingApplications',
        'approved': 'approvedApplications',
        'rejected': 'rejectedApplications'
    };

    // Initialiser les compteurs à 0
    Object.values(statMap).forEach(id => {
        document.getElementById(id).textContent = '0';
    });

    // Mettre à jour avec les données reçues
    stats.forEach(stat => {
        if (statMap[stat._id]) {
            const count = stat.count || 0;
            total += count;
            document.getElementById(statMap[stat._id]).textContent = count;
        }
    });

    document.getElementById('totalApplications').textContent = total;
}

function updateChart(stats) {
    const ctx = document.getElementById('applicationsChart').getContext('2d');
    
    // Détruire le graphique existant s'il y en a un
    if (window.myChart) {
        window.myChart.destroy();
    }

    const statusTotals = {
        'En attente': 0,
        'Approuvées': 0,
        'Rejetées': 0
    };

    const statusMap = {
        pending: 'En attente',
        approved: 'Approuvées',
        rejected: 'Rejetées'
    };

    if (Array.isArray(stats)) {
        stats.forEach(stat => {
            if (stat && stat._id && statusMap[stat._id]) {
                statusTotals[statusMap[stat._id]] = parseInt(stat.count) || 0;
            }
        });
    }

    window.myChart = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: Object.keys(statusTotals),
            datasets: [{
                data: Object.values(statusTotals),
                backgroundColor: [
                    '#f59e0b',
                    '#10b981',
                    '#ef4444'
                ],
                borderColor: '#ffffff',
                borderWidth: 2,
                hoverOffset: 4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'right',
                    labels: {
                        usePointStyle: true,
                        padding: 20,
                        font: {
                            size: 12,
                            family: "'Inter', sans-serif"
                        }
                    }
                },
                tooltip: {
                    backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    titleFont: {
                        size: 13,
                        family: "'Inter', sans-serif"
                    },
                    bodyFont: {
                        size: 12,
                        family: "'Inter', sans-serif"
                    },
                    padding: 12,
                    callbacks: {
                        label: function(context) {
                            const label = context.label || '';
                            const value = context.parsed || 0;
                            const total = context.dataset.data.reduce((acc, curr) => acc + curr, 0);
                            const percentage = total ? Math.round((value * 100) / total) : 0;
                            return `${label}: ${value} (${percentage}%)`;
                        }
                    }
                }
            },
            cutout: '60%',
            radius: '90%'
        }
    });

    const totalDemandes = Object.values(statusTotals).reduce((acc, curr) => acc + curr, 0);
    Chart.register({
        id: 'centerText',
        afterDraw: (chart) => {
            const { ctx, chartArea: { left, top, width, height } } = chart;
            ctx.save();
            ctx.font = 'bold 16px Inter';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillStyle = getComputedStyle(document.documentElement).getPropertyValue('--text-color');
            ctx.fillText(`Total: ${totalDemandes}`, left + width / 2, top + height / 2);
            ctx.restore();
        }
    });
}

// Variables pour la pagination et le filtrage
let currentPage = 1;
const itemsPerPage = 5;
let allApplications = [];
let filteredApplications = [];

function getStatusText(status) {
    const statusMap = {
        pending: 'En attente',
        approved: 'Approuvée',
        rejected: 'Rejetée'
    };
    return statusMap[status] || 'En attente';
}

// Load applications with pagination
async function loadApplications() {
    try {
        console.log('Chargement des demandes...');
        const response = await fetch('/api/loans', {
            headers: getHeaders(),
            credentials: 'include'
        });

        if (!response.ok) {
            if (response.status === 401) {
                localStorage.removeItem('userInfo');
                window.location.href = '/login.html';
                return;
            }
            const errorData = await response.json();
            throw new Error(errorData.message || 'Erreur lors du chargement des demandes');
        }

        const result = await response.json();
        console.log('Résultat reçu:', result);
        
        if (result.success) {
            allApplications = result.data || [];
            console.log('Nombre total de demandes:', allApplications.length);
            displayApplications(getPaginatedData());
            updatePagination();
        } else {
            throw new Error(result.message || 'Erreur lors du chargement des demandes');
        }
    } catch (error) {
        console.error('Erreur:', error);
        showError(error.message || 'Erreur lors du chargement des demandes');
    }
}

// Get paginated data
function getPaginatedData() {
    const filteredData = filterApplications(allApplications);
    console.log('Données filtrées:', filteredData.length);
    const startIndex = (currentPage - 1) * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;
    const paginatedData = filteredData.slice(startIndex, endIndex);
    console.log('Données paginées:', paginatedData.length);
    return paginatedData;
}

// Update pagination controls
function updatePagination() {
    const filteredData = filterApplications(allApplications);
    const totalPages = Math.max(1, Math.ceil(filteredData.length / itemsPerPage));
    
    document.getElementById('currentPage').textContent = currentPage;
    document.getElementById('totalPages').textContent = totalPages;
    
    const prevButton = document.getElementById('prevPage');
    const nextButton = document.getElementById('nextPage');
    
    if (prevButton && nextButton) {
        prevButton.disabled = currentPage <= 1;
        nextButton.disabled = currentPage >= totalPages;
    }
}

// Filter applications
function filterApplications(applications) {
    if (!Array.isArray(applications)) return [];
    
    const status = statusFilter?.value || 'all';
    const search = searchInput?.value.toLowerCase() || '';
    
    return applications.filter(app => {
        if (!app?.user) return false;
        
        let statusMatch = false;
        const appStatus = getStatusText(app.status).toLowerCase();
        
        if (status === 'all') {
            statusMatch = true;
        } else if (status === 'pending') {
            statusMatch = appStatus.includes('en attente');
        } else if (status === 'approved') {
            statusMatch = appStatus.includes('approuvée');
        } else if (status === 'rejected') {
            statusMatch = appStatus.includes('rejetée');
        }
        
        const searchMatch = (
            app.user.name.toLowerCase().includes(search) ||
            app.loanAmount.toString().includes(search) ||
            appStatus.includes(search)
        );
        
        return statusMatch && searchMatch;
    });
}

// Display applications
function displayApplications(applications) {
    console.log('Affichage des demandes:', applications);
    const tbody = document.getElementById('applicationsTableBody');
    if (!tbody) {
        console.error('Tableau non trouvé');
        return;
    }

    tbody.innerHTML = '';
    if (!Array.isArray(applications)) {
        console.error('Les données ne sont pas un tableau');
        return;
    }

    applications.forEach(app => {
        if (!app?.user) {
            console.warn('Application sans utilisateur:', app);
            return;
        }

        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>${app.user.name || 'N/A'}</td>
            <td>${app.loanAmount ? app.loanAmount.toLocaleString('fr-DZ') + ' DA' : 'N/A'}</td>
            <td><span class="status ${app.status || 'pending'}">${getStatusText(app.status)}</span></td>
            <td><span class="status ${app.mlPrediction === 'default' ? 'rejected' : 'approved'}">
                ${app.mlPrediction === 'default' ? 'Risqué' : 'Sûr'}
            </span></td>
            <td class="action-buttons">
                <button class="btn-primary btn-sm" onclick="viewApplication('${app._id}')">
                    <i class="fas fa-eye"></i> Détails
                </button>
                ${app.status === 'pending' ? `
                    <button class="btn-primary btn-success btn-sm" onclick="updateApplicationStatus('approved', '${app._id}')">
                        <i class="fas fa-check"></i> Approuver
                    </button>
                    <button class="btn-primary btn-danger btn-sm" onclick="updateApplicationStatus('rejected', '${app._id}')">
                        <i class="fas fa-times"></i> Rejeter
                    </button>
                ` : ''}
            </td>
        `;
        tbody.appendChild(tr);
    });
    
    updatePagination();
}

// Event listeners for pagination
document.getElementById('prevPage')?.addEventListener('click', () => {
    if (currentPage > 1) {
        currentPage--;
        displayApplications(getPaginatedData());
    }
});

document.getElementById('nextPage')?.addEventListener('click', () => {
    const filteredData = filterApplications(allApplications);
    const totalPages = Math.ceil(filteredData.length / itemsPerPage);
    if (currentPage < totalPages) {
        currentPage++;
        displayApplications(getPaginatedData());
    }

});

// Event listeners for filters
const statusFilter = document.getElementById('statusFilter');
const searchInput = document.getElementById('searchInput');

if (statusFilter) {
    statusFilter.addEventListener('change', () => {
        currentPage = 1;
        displayApplications(getPaginatedData());
    });
}

if (searchInput) {
    searchInput.addEventListener('input', () => {
        currentPage = 1;
        displayApplications(getPaginatedData());
    });
}

// Application modal
const applicationModal = document.getElementById('applicationModal');
let currentApplicationId = null;

async function viewApplication(id) {
    try {
        if (!id) throw new Error('ID de demande invalide');

        // Trouver la demande dans les données déjà chargées
        const application = allApplications.find(app => app._id === id);
        
        if (!application) {
            throw new Error('Demande non trouvée');
        }

        currentApplicationId = id;
        displayApplicationDetails(application);
        applicationModal.style.display = 'block';
    } catch (error) {
        showError(error.message || 'Erreur lors du chargement des détails');
    }
}

// Make viewApplication and updateApplicationStatus available globally
window.viewApplication = viewApplication;
window.updateApplicationStatus = updateApplicationStatus;

function displayApplicationDetails(application) {
    if (!application || !application.user) return;

    const details = document.getElementById('applicationDetails');
    if (!details) return;

    details.innerHTML = `
        <div class="details-grid">
            <div class="detail-item">
                <strong>Client:</strong> ${application.user.name || 'N/A'}
            </div>
            <div class="detail-item">
                <strong>Âge:</strong> ${application.age || 'N/A'} ans
            </div>
            <div class="detail-item">
                <strong>Revenu:</strong> ${application.income ? application.income.toLocaleString('fr-DZ') + ' DA' : 'N/A'}
            </div>
            <div class="detail-item">
                <strong>Montant demandé:</strong> ${application.loanAmount ? application.loanAmount.toLocaleString('fr-DZ') + ' DA' : 'N/A'}
            </div>
            <div class="detail-item">
                <strong>Durée d'emploi:</strong> ${application.employmentLength || 'N/A'} mois
            </div>
            <div class="detail-item">
                <strong>Type de résidence:</strong> ${application.homeStatus || 'N/A'}
            </div>
            <div class="detail-item">
                <strong>Objet du prêt:</strong> ${application.loanPurpose || 'N/A'}
            </div>
            <div class="detail-item">
                <strong>Prédiction IA:</strong> 
                <span class="status ${application.mlPrediction === 'default' ? 'rejected' : 'approved'}">
                    ${application.mlPrediction === 'default' ? 'Risqué' : 'Sûr'}
                </span>
            </div>
        </div>
    `;
}

// Application status updates
async function updateApplicationStatus(status, id) {
    if (!id || !status) return;

    try {
        const response = await fetch(`/api/loans/${id}/status`, {
            method: 'PUT',
            headers: getHeaders(),
            body: JSON.stringify({ status }),
            credentials: 'include'
        });

        if (!response.ok) {
            if (response.status === 401) {
                localStorage.removeItem('userInfo');
                window.location.href = '/login.html';
                return;
            }
            throw new Error('Erreur lors de la mise �� jour du statut');
        }

        const result = await response.json();
        if (result.success) {
            showSuccess('Statut mis à jour avec succès');
            await Promise.all([loadStats(), loadApplications()]);
        } else {
            throw new Error(result.message);
        }
    } catch (error) {
        showError(error.message);
    }
}

// Event listeners for status buttons
document.getElementById('approveBtn')?.addEventListener('click', () => updateApplicationStatus('approved', currentApplicationId));
document.getElementById('rejectBtn')?.addEventListener('click', () => updateApplicationStatus('rejected', currentApplicationId));
document.getElementById('pendingBtn')?.addEventListener('click', () => updateApplicationStatus('pending', currentApplicationId));

// Modal handling
const closeButtons = document.getElementsByClassName('close');

Array.from(closeButtons).forEach(button => {
    button.addEventListener('click', () => {
        const modal = button.closest('.modal');
        if (modal) modal.style.display = 'none';
    });
});

window.addEventListener('click', (e) => {
    if (e.target.classList.contains('modal')) {
        e.target.style.display = 'none';
    }
});

// Profile modal
const profileModal = document.getElementById('profileModal');
const editProfile = document.getElementById('editProfile');

if (editProfile) {
    editProfile.addEventListener('click', (e) => {
        e.preventDefault();
        if (profileModal) {
            profileModal.style.display = 'block';
            document.getElementById('profileName').value = userInfo.name || '';
            document.getElementById('profileEmail').value = userInfo.email || '';
        }
    });
}

// Profile update
const profileForm = document.getElementById('profileForm');

profileForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    const formData = new FormData();
    formData.append('name', document.getElementById('profileName').value);
    formData.append('email', document.getElementById('profileEmail').value);

    const profileImage = document.getElementById('profileImageInput').files[0];
    if (profileImage) {
        formData.append('profileImage', profileImage);
    }

    try {
        const response = await fetch('/api/users/profile', {
            method: 'PUT',
            headers: {
                'Authorization': `Bearer ${userInfo.token}`
            },
            body: formData,
            credentials: 'include'
        });

        if (!response.ok) {
            if (response.status === 401) {
                localStorage.removeItem('userInfo');
                window.location.href = '/login.html';
                return;
            }
            const errorData = await response.json();
            throw new Error(errorData.message || 'Erreur lors de la mise à jour');
        }

        const data = await response.json();
        
        if (data.success && data.data) {
            // Mise à jour des informations locales
            Object.assign(userInfo, {
                name: data.data.name,
                email: data.data.email,
                profileImage: data.data.profileImage || userInfo.profileImage
            });
            
            localStorage.setItem('userInfo', JSON.stringify(userInfo));

            // Mise à jour de l'interface
            initializeUserProfile();

            // Fermer le modal et afficher le succès
            profileModal.style.display = 'none';
            showSuccess('Profil mis à jour avec succès');
        } else {
            throw new Error(data.message || 'Données de mise à jour invalides');
        }
    } catch (error) {
        showError(error.message || 'Erreur lors de la mise à jour du profil');
    }
});

// Logout
const logoutButton = document.getElementById('logout');

if (logoutButton) {
    logoutButton.addEventListener('click', async (e) => {
        e.preventDefault();
        try {
            const response = await fetch('/api/users/logout', {
                method: 'POST',
                headers: getHeaders(),
                credentials: 'include'
            });

            if (!response.ok) {
                throw new Error('Erreur lors de la déconnexion');
            }

            localStorage.removeItem('userInfo');
            window.location.href = '/login.html';
        } catch (error) {
            showError(error.message || 'Erreur lors de la déconnexion');
        }
    });
}

// Error and Success messages
function showError(message) {
    const container = document.querySelector('.dashboard-container');
    if (!container) return;

    const errorDiv = document.createElement('div');
    errorDiv.className = 'error-message';
    errorDiv.textContent = message;
    container.insertBefore(errorDiv, container.firstChild);
    setTimeout(() => errorDiv.remove(), 5000);
}

function showSuccess(message) {
    const container = document.querySelector('.dashboard-container');
    if (!container) return;

    const successDiv = document.createElement('div');
    successDiv.className = 'success-message';
    successDiv.textContent = message;
    container.insertBefore(successDiv, container.firstChild);
    setTimeout(() => successDiv.remove(), 5000);
}

// Initial load
loadStats();
loadApplications();