// État global
let currentModel = null;
let isTraining = false;

// Gestionnaire d'événements pour le sélecteur de modèle
document.getElementById('modelSelect').addEventListener('change', function(e) {
    const customUpload = document.getElementById('customModelUpload');
    customUpload.style.display = e.target.value === 'custom' ? 'block' : 'none';
});

// Fonction pour charger un modèle personnalisé
async function uploadModel() {
    const fileInput = document.getElementById('modelFile');
    const file = fileInput.files[0];
    
    if (!file) {
        alert('Veuillez sélectionner un fichier Python (.py)');
        return;
    }

    const formData = new FormData();
    formData.append('model', file);

    try {
        const response = await fetch('/api/upload-model', {
            method: 'POST',
            body: formData
        });

        if (response.ok) {
            const result = await response.json();
            alert('Modèle chargé avec succès!');
            currentModel = 'custom';
        } else {
            throw new Error('Erreur lors du chargement du modèle');
        }
    } catch (error) {
        console.error('Erreur:', error);
        alert('Erreur lors du chargement du modèle: ' + error.message);
    }
}

// Fonction pour entraîner le modèle
async function trainModel() {
    const modelType = document.getElementById('modelSelect').value;
    const trainingStatus = document.getElementById('trainingStatus');
    
    if (isTraining) {
        alert('Un entraînement est déjà en cours');
        return;
    }

    isTraining = true;
    trainingStatus.innerHTML = '<div class="loading"></div> Entraînement en cours...';

    try {
        const response = await fetch('/api/train-model', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                modelType,
                dataset: 'credit_risk_balanced.csv'
            })
        });

        if (response.ok) {
            const result = await response.json();
            trainingStatus.textContent = 'Entraînement terminé avec succès!';
            currentModel = modelType;
        } else {
            const error = await response.json();
            throw new Error(error.error || 'Erreur lors de l\'entraînement');
        }
    } catch (error) {
        console.error('Erreur:', error);
        trainingStatus.textContent = 'Erreur lors de l\'entraînement: ' + error.message;
    } finally {
        isTraining = false;
    }
}

// Gestionnaire du formulaire de prédiction
document.getElementById('predictionForm').addEventListener('submit', async function(e) {
    e.preventDefault();

    if (!currentModel) {
        alert('Veuillez d\'abord entraîner un modèle');
        return;
    }

    const formData = {
        age: document.getElementById('age').value,
        income: document.getElementById('income').value,
        employment_length: document.getElementById('employment_length').value,
        loan_amount: document.getElementById('loan_amount').value
    };

    const predictionResult = document.getElementById('predictionResult');
    predictionResult.innerHTML = '<div class="loading"></div> Analyse en cours...';

    try {
        const response = await fetch('/api/predict', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                modelType: currentModel,
                data: formData
            })
        });

        if (response.ok) {
            const result = await response.json();
            let resultHtml = `
                <h3>Résultat de l'analyse</h3>
                <p>Probabilité d'approbation: ${(result.probability * 100).toFixed(2)}%</p>
                <p>Recommandation: ${result.probability > 0.5 ? 
                    '<span style="color: green">Crédit Recommandé</span>' : 
                    '<span style="color: red">Crédit Non Recommandé</span>'}</p>
            `;
            predictionResult.innerHTML = resultHtml;
        } else {
            const error = await response.json();
            throw new Error(error.error || 'Erreur lors de la prédiction');
        }
    } catch (error) {
        console.error('Erreur:', error);
        predictionResult.textContent = 'Erreur lors de la prédiction: ' + error.message;
    }
}); 