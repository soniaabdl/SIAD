// Handle form submissions
const loginForm = document.getElementById('loginForm');
const signupForm = document.getElementById('signupForm');

if (loginForm) {
    loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const formData = {
            email: document.getElementById('email').value,
            password: document.getElementById('password').value,
            role: document.getElementById('role').value
        };

        try {
            const response = await fetch('/api/users/login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(formData),
                credentials: 'include'
            });

            const data = await response.json();

            if (response.ok) {
                // Save both user info and token
                const userInfo = {
                    _id: data._id,
                    name: data.name,
                    email: data.email,
                    role: data.role,
                    token: data.token // Save the token
                };
                localStorage.setItem('userInfo', JSON.stringify(userInfo));
                window.location.href = data.role === 'banker' ? '/banker-dashboard.html' : '/client-dashboard.html';
            } else {
                const errorMessage = data.message || 'Erreur de connexion';
                showError(errorMessage);
            }
        } catch (error) {
            showError('Erreur de connexion au serveur');
        }
    });
}

if (signupForm) {
    signupForm.addEventListener('submit', async (e) => {
        e.preventDefault();

        const password = document.getElementById('password').value;
        const confirmPassword = document.getElementById('confirmPassword').value;

        if (password !== confirmPassword) {
            showError('Les mots de passe ne correspondent pas');
            return;
        }

        const formData = {
            name: document.getElementById('name').value,
            email: document.getElementById('email').value,
            password: password,
            role: document.getElementById('role').value
        };

        try {
            const response = await fetch('/api/users/register', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(formData),
                credentials: 'include'
            });

            const data = await response.json();

            if (response.ok) {
                // Save both user info and token
                const userInfo = {
                    _id: data._id,
                    name: data.name,
                    email: data.email,
                    role: data.role,
                    token: data.token // Save the token
                };
                localStorage.setItem('userInfo', JSON.stringify(userInfo));
                window.location.href = data.role === 'banker' ? '/banker-dashboard.html' : '/client-dashboard.html';
            } else {
                const errorMessage = data.message || 'Erreur d\'inscription';
                showError(errorMessage);
            }
        } catch (error) {
            showError('Erreur de connexion au serveur');
        }
    });
}

// Error handling
function showError(message) {
    const errorDiv = document.createElement('div');
    errorDiv.className = 'error-message';
    errorDiv.textContent = message;

    const form = document.querySelector('.auth-form');
    const existingError = form.querySelector('.error-message');
    
    if (existingError) {
        existingError.remove();
    }
    
    form.insertBefore(errorDiv, form.firstChild);

    setTimeout(() => {
        errorDiv.remove();
    }, 5000);
}

// Check if user is already logged in and has valid token
const userInfo = localStorage.getItem('userInfo');
if (userInfo) {
    const user = JSON.parse(userInfo);
    if (user.token) { // Only redirect if token exists
        window.location.href = user.role === 'banker' ? '/banker-dashboard.html' : '/client-dashboard.html';
    } else {
        localStorage.removeItem('userInfo'); // Clear invalid data
    }
}

// Theme handling
const body = document.body;
const savedTheme = localStorage.getItem('theme');
if (savedTheme) {
    body.classList.add(savedTheme);
}