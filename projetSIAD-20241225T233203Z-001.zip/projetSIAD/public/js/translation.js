const translations = {
    fr: {
        'Monthly Income': 'Revenu Mensuel',
        'Loan Amount': 'Montant du Prêt',
        'Duration': 'Durée',
        'Calculate': 'Calculer',
        'Monthly Payment': 'Paiement Mensuel',
        'Total Cost': 'Coût Total',
        'Total Interest': 'Total des Intérêts',
        'Submit Application': 'Soumettre la Demande',
        'Profile': 'Profil',
        'Logout': 'Déconnexion',
        'Edit Profile': 'Modifier le Profil',
        'Save': 'Sauvegarder',
        'Cancel': 'Annuler'
    },
    en: {
        'Revenu Mensuel': 'Monthly Income',
        'Montant du Prêt': 'Loan Amount',
        'Durée': 'Duration',
        'Calculer': 'Calculate',
        'Paiement Mensuel': 'Monthly Payment',
        'Coût Total': 'Total Cost',
        'Total des Intérêts': 'Total Interest',
        'Soumettre la Demande': 'Submit Application',
        'Profil': 'Profile',
        'Déconnexion': 'Logout',
        'Modifier le Profil': 'Edit Profile',
        'Sauvegarder': 'Save',
        'Annuler': 'Cancel'
    }
};

let currentLang = 'fr';

document.getElementById('translateBtn').addEventListener('click', () => {
    currentLang = currentLang === 'fr' ? 'en' : 'fr';
    translatePage();
});

function translatePage() {
    const elements = document.querySelectorAll('[data-translate]');
    elements.forEach(element => {
        const key = element.getAttribute('data-translate');
        if (translations[currentLang][key]) {
            element.textContent = translations[currentLang][key];
        }
    });

    // Update button text
    document.getElementById('translateBtn').querySelector('span').textContent = 
        currentLang === 'fr' ? 'FR/EN' : 'EN/FR';
}

// Add translation data attributes to elements
document.addEventListener('DOMContentLoaded', () => {
    const elements = document.querySelectorAll('label, button, h1, h2, h3, p');
    elements.forEach(element => {
        const text = element.textContent.trim();
        if (translations.fr[text] || translations.en[text]) {
            element.setAttribute('data-translate', text);
        }
    });
});