// Check authentication
const userInfo = JSON.parse(localStorage.getItem('userInfo'));
if (!userInfo || !userInfo.token) {
    window.location.href = '/login.html';
}

// Initialize user profile
function initializeUserProfile() {
    try {
        document.getElementById('userName').textContent = userInfo.name || 'Client';
        const profileImage = document.getElementById('profileImage');
        if (profileImage) {
            profileImage.src = userInfo.profileImage || '/uploads/default-profile.png';
            profileImage.onerror = () => {
                profileImage.src = '/uploads/default-profile.png';
            };
        }
    } catch (error) {
        console.error('Erreur lors de l\'initialisation du profil:', error);
        showError('Erreur lors de l\'affichage du profil');
    }
}

// Initial profile setup
initializeUserProfile();

// API Headers
const getHeaders = () => {
    const headers = {
        'Content-Type': 'application/json'
    };
    if (userInfo && userInfo.token) {
        headers['Authorization'] = `Bearer ${userInfo.token}`;
    }
    return headers;
};

// Theme handling
const body = document.body;
const themeToggle = document.getElementById('themeToggle');
const savedTheme = localStorage.getItem('theme');

if (savedTheme) {
    body.classList.add(savedTheme);
    updateThemeIcon();
}

themeToggle.addEventListener('click', () => {
    body.classList.toggle('dark-mode');
    updateThemeIcon();
    localStorage.setItem('theme', body.classList.contains('dark-mode') ? 'dark-mode' : '');
});

function updateThemeIcon() {
    const icon = themeToggle.querySelector('i');
    if (body.classList.contains('dark-mode')) {
        icon.classList.remove('fa-moon');
        icon.classList.add('fa-sun');
    } else {
        icon.classList.remove('fa-sun');
        icon.classList.add('fa-moon');
    }
}

// Load user profile
document.getElementById('userName').textContent = userInfo.name;
if (userInfo.profileImage) {
    document.getElementById('profileImage').src = userInfo.profileImage;
}

// Loan calculator
const loanCalculatorForm = document.getElementById('loanCalculatorForm');
const calculationResults = document.getElementById('calculationResults');

loanCalculatorForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    const formData = {
        loanAmount: Number(document.getElementById('loanAmountCalc').value),
        duration: Number(document.getElementById('loanDuration').value),
        income: Number(document.getElementById('monthlyIncome').value)
    };

    try {
        const response = await fetch('/api/loans/simulate', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${userInfo.token}`
            },
            body: JSON.stringify(formData),
            credentials: 'include'
        });

        if (!response.ok) {
            if (response.status === 401) {
                localStorage.removeItem('userInfo');
                window.location.href = '/login.html';
                return;
            }
            const errorData = await response.json();
            throw new Error(errorData.message || 'Erreur lors de la simulation');
        }

        const result = await response.json();
        
        if (result.success) {
            const data = result.data;
            document.getElementById('monthlyPayment').textContent = `${data.monthlyPayment} DA`;
            document.getElementById('totalCost').textContent = `${data.totalPayment} DA`;
            document.getElementById('totalInterest').textContent = `${data.totalInterest} DA`;
            calculationResults.classList.remove('hidden');
        } else {
            throw new Error(result.message || 'Erreur lors de la simulation');
        }
    } catch (error) {
        showError(error.message || 'Erreur lors de la simulation du prêt');
    }
});

// Loan application
const loanApplicationForm = document.getElementById('loanApplicationForm');

loanApplicationForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    const formData = {
        age: document.getElementById('age').value,
        income: document.getElementById('income').value,
        homeStatus: document.getElementById('homeStatus').value,
        employmentLength: document.getElementById('employmentLength').value,
        loanPurpose: document.getElementById('loanPurpose').value,
        loanAmount: document.getElementById('loanAmountApp').value,
        employmentStatus: document.getElementById('employmentStatus').value
    };

    try {
        const response = await fetch('/api/loans', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${userInfo.token}`
            },
            body: JSON.stringify(formData),
            credentials: 'include'
        });

        if (!response.ok) {
            if (response.status === 401) {
                localStorage.removeItem('userInfo');
                window.location.href = '/login.html';
                return;
            }
            const errorData = await response.json();
            throw new Error(errorData.message || 'Erreur lors de la soumission');
        }

        const data = await response.json();
        
        if (data.success) {
            showSuccess('Demande de crédit soumise avec succès!');
            loanApplicationForm.reset();
            loadLoanSummary();
        } else {
            throw new Error(data.message || 'Erreur lors de la soumission');
        }
    } catch (error) {
        showError(error.message || 'Erreur lors de la soumission de la demande');
    }
});

// Load loan summary
async function loadLoanSummary() {
    try {
        const response = await fetch('/api/loans', {
            headers: getHeaders(),
            credentials: 'include'
        });

        if (!response.ok) {
            if (response.status === 401) {
                localStorage.removeItem('userInfo');
                window.location.href = '/login.html';
                return;
            }
            throw new Error(await response.text());
        }

        const loans = await response.json();
        if (loans.length > 0) {
            const latestLoan = loans[0];
            document.getElementById('loanAmount').textContent = `${latestLoan.loanAmount} DA`;
            document.getElementById('loanStatus').textContent = getStatusText(latestLoan.status);
            document.getElementById('loanStatus').className = `status ${latestLoan.status}`;
            document.getElementById('interestRate').textContent = `${latestLoan.interestRate}%`;
        }
    } catch (error) {
        showError(error.message || 'Erreur lors du chargement des données');
    }
}

function getStatusText(status) {
    const statusMap = {
        'pending': 'En attente',
        'approved': 'Approuvée',
        'rejected': 'Rejetée'
    };
    return statusMap[status] || status;
}

// Error and Success messages
function showError(message) {
    const errorDiv = document.createElement('div');
    errorDiv.className = 'error-message';
    errorDiv.textContent = message;
    document.querySelector('.dashboard-container').insertBefore(errorDiv, document.querySelector('.dashboard-container').firstChild);
    setTimeout(() => errorDiv.remove(), 5000);
}

function showSuccess(message) {
    const successDiv = document.createElement('div');
    successDiv.className = 'success-message';
    successDiv.textContent = message;
    document.querySelector('.dashboard-container').insertBefore(successDiv, document.querySelector('.dashboard-container').firstChild);
    setTimeout(() => successDiv.remove(), 5000);
}

// Initial load
loadLoanSummary();

// Profile modal
const profileModal = document.getElementById('profileModal');
const editProfile = document.getElementById('editProfile');
const closeButtons = document.getElementsByClassName('close');

// Modal handling
editProfile.addEventListener('click', (e) => {
    e.preventDefault();
    profileModal.style.display = 'block';
    document.getElementById('profileName').value = userInfo.name;
    document.getElementById('profileEmail').value = userInfo.email;
});

Array.from(closeButtons).forEach(button => {
    button.addEventListener('click', () => {
        button.closest('.modal').style.display = 'none';
    });
});

window.addEventListener('click', (e) => {
    if (e.target.classList.contains('modal')) {
        e.target.style.display = 'none';
    }
});

// Profile update
const profileForm = document.getElementById('profileForm');

profileForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    const formData = new FormData();
    formData.append('name', document.getElementById('profileName').value);
    formData.append('email', document.getElementById('profileEmail').value);

    const profileImage = document.getElementById('profileImageInput').files[0];
    if (profileImage) {
        formData.append('profileImage', profileImage);
    }

    try {
        const response = await fetch('/api/users/profile', {
            method: 'PUT',
            headers: {
                'Authorization': `Bearer ${userInfo.token}`
            },
            body: formData,
            credentials: 'include'
        });

        if (!response.ok) {
            if (response.status === 401) {
                localStorage.removeItem('userInfo');
                window.location.href = '/login.html';
                return;
            }
            const errorData = await response.json();
            throw new Error(errorData.message || 'Erreur lors de la mise à jour');
        }

        const data = await response.json();
        
        if (data.success && data.data) {
            // Mise à jour des informations locales
            Object.assign(userInfo, {
                name: data.data.name,
                email: data.data.email,
                profileImage: data.data.profileImage || userInfo.profileImage
            });
            
            localStorage.setItem('userInfo', JSON.stringify(userInfo));

            // Mise à jour de l'interface
            initializeUserProfile();

            // Fermer le modal et afficher le succès
            profileModal.style.display = 'none';
            showSuccess('Profil mis à jour avec succès');
        } else {
            throw new Error(data.message || 'Données de mise à jour invalides');
        }
    } catch (error) {
        showError(error.message || 'Erreur lors de la mise à jour du profil');
    }
});

// Logout
const logoutButton = document.getElementById('logout');

logoutButton.addEventListener('click', async (e) => {
    e.preventDefault();
    
    try {
        const response = await fetch('/api/users/logout', {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${userInfo.token}`
            },
            credentials: 'include'
        });

        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.message || 'Erreur lors de la déconnexion');
        }

        // Nettoyage local et redirection
        localStorage.removeItem('userInfo');
        window.location.href = '/login.html';
    } catch (error) {
        showError(error.message || 'Erreur lors de la déconnexion');
    }
});

// Variables pour la pagination
let currentPage = 1;
const itemsPerPage = 5;
let creditHistory = [];

// Fonction pour charger l'historique des crédits
async function loadCreditHistory() {
    try {
        const response = await fetch('/api/loans', {
            headers: getHeaders(),
            credentials: 'include'
        });
        if (!response.ok) {
            if (response.status === 401) {
                localStorage.removeItem('userInfo');
                window.location.href = '/login.html';
                return;
            }
            throw new Error('Erreur lors du chargement de l\'historique');
        }
        
        const result = await response.json();
        if (result.success && Array.isArray(result.data)) {
            creditHistory = result.data.map(loan => ({
                date: loan.createdAt,
                amount: loan.loanAmount,
                purpose: loan.loanPurpose,
                status: loan.status.toUpperCase(),
                monthlyPayment: calculateMonthlyPayment(loan.loanAmount, loan.interestRate)
            }));
            displayCreditHistory();
            updatePaginationButtons();
        }
    } catch (error) {
        console.error('Erreur:', error);
        showError('Erreur lors du chargement de l\'historique des crédits');
    }
}

// Fonction pour calculer le paiement mensuel
function calculateMonthlyPayment(loanAmount, annualInterestRate) {
    const monthlyInterestRate = annualInterestRate / 12;
    const duration = 24; // Durée fixe de 24 mois
    return Math.round((loanAmount * monthlyInterestRate * Math.pow(1 + monthlyInterestRate, duration)) /
        (Math.pow(1 + monthlyInterestRate, duration) - 1));
}

// Fonction pour afficher l'historique des crédits
function displayCreditHistory() {
    const tbody = document.getElementById('creditHistoryBody');
    const startIndex = (currentPage - 1) * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;
    const currentItems = creditHistory.slice(startIndex, endIndex);

    tbody.innerHTML = '';
    
    currentItems.forEach(credit => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${new Date(credit.date).toLocaleDateString()}</td>
            <td>${credit.amount.toLocaleString()} DA</td>
            <td>${translateLoanPurpose(credit.purpose)}</td>
            <td><span class="status ${credit.status.toLowerCase()}">${translateStatus(credit.status)}</span></td>
            <td>${credit.monthlyPayment.toLocaleString()} DA</td>
        `;
        tbody.appendChild(row);
    });
}

// Fonction pour mettre à jour les boutons de pagination
function updatePaginationButtons() {
    const prevBtn = document.getElementById('prevPage');
    const nextBtn = document.getElementById('nextPage');
    const currentPageSpan = document.getElementById('currentPage');
    
    const totalPages = Math.ceil(creditHistory.length / itemsPerPage);
    
    prevBtn.disabled = currentPage === 1;
    nextBtn.disabled = currentPage === totalPages;
    
    currentPageSpan.textContent = `Page ${currentPage} sur ${totalPages}`;
}

// Fonction pour traduire l'objet du prêt
function translateLoanPurpose(purpose) {
    const purposes = {
        'PERSONAL': 'Personnel',
        'EDUCATION': 'Éducation',
        'MEDICAL': 'Médical',
        'BUSINESS': 'Entreprise'
    };
    return purposes[purpose] || purpose;
}

// Fonction pour traduire le statut
function translateStatus(status) {
    const statuses = {
        'PENDING': 'En attente',
        'APPROVED': 'Approuvé',
        'REJECTED': 'Rejeté',
        'COMPLETED': 'Terminé'
    };
    return statuses[status] || status;
}

// Gestionnaires d'événements pour la pagination
document.getElementById('prevPage').addEventListener('click', () => {
    if (currentPage > 1) {
        currentPage--;
        displayCreditHistory();
        updatePaginationButtons();
    }
});

document.getElementById('nextPage').addEventListener('click', () => {
    const totalPages = Math.ceil(creditHistory.length / itemsPerPage);
    if (currentPage < totalPages) {
        currentPage++;
        displayCreditHistory();
        updatePaginationButtons();
    }
});

// Charger l'historique des crédits au chargement de la page
document.addEventListener('DOMContentLoaded', () => {
    loadCreditHistory();
    // ... autres initialisations existantes ...
});